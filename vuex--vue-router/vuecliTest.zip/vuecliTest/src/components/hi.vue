<template>
  <div class="hello">
    <h1>{{ msg }}</h1>

    <router-view></router-view>
  </div>
</template>

<script type="text/ecmascript-6">
export default {
  name: 'hi',
  data () {
    return {
      msg: 'Hi, I am feng'
    }
  }
}
</script>

<style>

</style>
