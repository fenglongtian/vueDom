<template>
  <div>
    <h2>{{msg}}</h2>
    <hr/>
    <h3>{{$store.state.count}}--{{count}}</h3>
    <div>
      <button @click="$store.commit('add')">+</button>
      <button @click="$store.commit('reduce')">-</button>
    </div>

  </div>
</template>
<script>
import store from '@/vuex/store'
import { mapState,mapMutations,mapGetters,mapActions } from 'vuex'
export default{
  data () {
    return {
      msg: 'Hello Vuex'
    }
  },
  // computed:mapState({
  //   count:state=>state.count
  // }),

  methods:{
    ...mapMutations([
      'add','reduce'
    ]),
    ...mapActions(['addAction','reduceAction'])
  },
//  computed:mapState(["count"]),
  computed:{
    ...mapState(["count"]),
//        count(){
//          return this.$store.getters.count;
//       },
    ...mapGetters(["count"])
  },
  store
}
</script>
