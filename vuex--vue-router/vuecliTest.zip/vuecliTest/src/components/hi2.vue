<template>
  <div class="hello">
    <h1>{{ msg }}--
      {{$route.params.username}}</h1>
  </div>
</template>

<script type="text/ecmascript-6">
export default {
  name: 'hi',
  data () {
    return {
      msg: 'Hi, I am h2'
    }
  }
}
</script>

<style>

</style>
